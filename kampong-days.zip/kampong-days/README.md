# Kampong Days · 甘榜童年

Singapore heritage games for seniors, by Tzu Chi Foundation Singapore.

## Put it on GitHub Pages
1. Create a new repository (or open your existing one under tzuchi-singapore).
2. Click **Add file → Upload files** and drag in **everything inside this folder**: `index.html` and the `img`, `music` and `vendor` folders.
3. Commit, then go to **Settings → Pages**, choose the `main` branch and `/ (root)`, and save.
4. After a minute the games are live at `https://<your-org>.github.io/<repo-name>/`.

## Notes
- **Online play (two devices):** both devices need internet. The game uses PeerJS (MIT licence, in `vendor/`) and its free public server only to introduce the two devices; the game data then goes directly between them.
- **Today's Top 20** on GitHub Pages is kept on each device (there is no shared server there).
- Music tracks were generated with Higgsfield. Folk songs are traditional and free of copyright.
